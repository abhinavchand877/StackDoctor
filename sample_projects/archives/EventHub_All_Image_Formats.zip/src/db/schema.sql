CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'student' CHECK (role IN ('student','admin')),
  department VARCHAR(100),
  year VARCHAR(30),
  phone VARCHAR(25),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS events (
  id SERIAL PRIMARY KEY,
  title VARCHAR(180) NOT NULL,
  description TEXT NOT NULL,
  category VARCHAR(80) NOT NULL DEFAULT 'General',
  venue VARCHAR(180) NOT NULL,
  event_date TIMESTAMPTZ NOT NULL,
  registration_deadline TIMESTAMPTZ,
  capacity INTEGER NOT NULL DEFAULT 100 CHECK (capacity > 0),
  banner_url TEXT,
  registration_fee NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (registration_fee >= 0),
  prize_money NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (prize_money >= 0),
  payment_instructions TEXT,
  pamphlet_url TEXT,
  is_published BOOLEAN NOT NULL DEFAULT TRUE,
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS registrations (
  id SERIAL PRIMARY KEY,
  event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  phone VARCHAR(25),
  department VARCHAR(100),
  year VARCHAR(30),
  status VARCHAR(20) NOT NULL DEFAULT 'registered' CHECK (status IN ('registered','attended','cancelled')),
  registered_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  checked_in_at TIMESTAMPTZ,
  UNIQUE(event_id,user_id)
);
CREATE INDEX IF NOT EXISTS idx_events_date ON events(event_date);
CREATE INDEX IF NOT EXISTS idx_registrations_event ON registrations(event_id);
CREATE INDEX IF NOT EXISTS idx_registrations_user ON registrations(user_id);
-- Safe migrations for databases created by earlier EventHub versions
ALTER TABLE users ADD COLUMN IF NOT EXISTS phone VARCHAR(25);
ALTER TABLE events ADD COLUMN IF NOT EXISTS registration_fee NUMERIC(10,2) NOT NULL DEFAULT 0;
ALTER TABLE events ADD COLUMN IF NOT EXISTS prize_money NUMERIC(10,2) NOT NULL DEFAULT 0;
ALTER TABLE events ADD COLUMN IF NOT EXISTS payment_instructions TEXT;
ALTER TABLE events ADD COLUMN IF NOT EXISTS pamphlet_url TEXT;

ALTER TABLE registrations ADD COLUMN IF NOT EXISTS phone VARCHAR(25);
ALTER TABLE registrations ADD COLUMN IF NOT EXISTS department VARCHAR(100);
ALTER TABLE registrations ADD COLUMN IF NOT EXISTS year VARCHAR(30);
