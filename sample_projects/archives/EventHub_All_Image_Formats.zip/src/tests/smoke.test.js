const test = require("node:test");
const assert = require("node:assert/strict");
test("EventHub project metadata is present", () => {
  const pkg = require("../package.json");
  assert.equal(pkg.name, "eventhub-cdd");
  assert.ok(pkg.scripts.start);
  assert.ok(pkg.dependencies.pg);
});
test("schema includes core relational tables", () => {
  const fs = require("node:fs");
  const schema = fs.readFileSync("db/schema.sql", "utf8");
  assert.match(schema, /CREATE TABLE IF NOT EXISTS users/);
  assert.match(schema, /CREATE TABLE IF NOT EXISTS events/);
  assert.match(schema, /CREATE TABLE IF NOT EXISTS registrations/);
  assert.match(schema, /UNIQUE\(event_id,user_id\)/);
});