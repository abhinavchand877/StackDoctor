# EventHub — College Event Registration & Check-in System

A full-stack Collaborative Development / DevOps project built with **HTML, CSS, JavaScript, Node.js, Express and PostgreSQL**. It includes separate student and administrator dashboards, college-email registration, event management, registration management and event-day check-in.

## Features

### Student dashboard
- Student account registration and login using college email.
- Browse published campus events; search and filter by category.
- View full event details, venue, date, deadline, capacity and remaining seats.
- Register once per event; capacity and deadline are checked on the server.
- View registrations, attendance status and cancel an active registration.

### Administrator dashboard
- Admin-only login and protected APIs.
- Dashboard totals: events, students, registrations and checked-in attendees.
- Create, edit and delete events.
- Search registrations by student name or college email; filter by event.
- View student directory and registration counts.
- Mark a registered student as attended at the event venue.

### Engineering / DevOps
- PostgreSQL relational schema, constraints and indexes.
- Password hashing with bcrypt; JWT authentication; role-based authorization.
- Parameterized SQL queries, Helmet headers and API rate limiting.
- Dockerfile + Docker Compose for app and database.
- GitHub Actions CI workflow and test command.
- Environment-based configuration; `.env` excluded from Git.

## Requirements
- Node.js 20+
- PostgreSQL 15+ (or Docker Desktop)
- npm

## Quick start — local PostgreSQL

1. Extract the ZIP and open the project folder in VS Code.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Copy `.env.example` to `.env` and edit it. Set your actual college email domain:
   ```env
   COLLEGE_EMAIL_DOMAIN=yourcollege.edu.in
   JWT_SECRET=use-a-long-random-secret-here
   ADMIN_EMAIL=admin@yourcollege.edu.in
   ADMIN_PASSWORD=ChooseAStrongAdminPassword
   ```
   If your college uses multiple email domains, update the validation in `src/routes/auth.js` to use an allow-list.
4. Create a PostgreSQL database named `eventhub` (or update `DATABASE_URL`).
5. Create tables and starter admin/sample events:
   ```bash
   npm run db:init
   npm run db:seed
   ```
6. Start the app:
   ```bash
   npm run dev
   ```
7. Open **http://localhost:3000**.

Starter admin credentials are the values you set in `.env` (`ADMIN_EMAIL` and `ADMIN_PASSWORD`). Do not use the sample password in a real deployment. Seed does not overwrite an existing account password.

## Quick start — Docker Compose

1. Install and start Docker Desktop.
2. Copy `.env.example` to `.env`; set a strong `JWT_SECRET` and admin password.
3. Run:
   ```bash
   docker compose up --build -d
   ```
4. Initialize and seed the database:
   ```bash
   docker compose exec app npm run db:init
   docker compose exec app npm run db:seed
   ```
5. Visit **http://localhost:3000**.

## Suggested demo flow
1. Sign in as administrator and show the dashboard statistics.
2. Create a new event, set a capacity of 2, and publish it.
3. Register two student accounts using your configured college email domain.
4. Sign in as each student and register for the event; show the capacity limit.
5. Sign back in as admin, search by college email, filter by event and check in a student.
6. Show the attended status and updated dashboard count.

## Collaborative development plan

Use GitHub with a shared `main` branch protected by pull requests.

| Team member | Responsibility | Suggested branch |
|---|---|---|
| Member 1 | UI/UX, responsive frontend and animations | `feature/frontend-ui` |
| Member 2 | Authentication and student dashboard | `feature/student-module` |
| Member 3 | Admin dashboard and event CRUD | `feature/admin-module` |
| Member 4 | PostgreSQL, integration, testing and DevOps | `feature/database-devops` |

Workflow:
1. Create an issue for each feature or bug.
2. Pull the latest `develop` branch and create a focused feature branch.
3. Commit small changes with clear messages, e.g. `feat: add event category filter`.
4. Push the branch and open a Pull Request.
5. Ask one teammate to review; resolve comments and merge.
6. Run `npm test` and verify the app before merging to `main`.

Recommended commit prefixes: `feat:`, `fix:`, `docs:`, `test:`, `refactor:`, `ci:`.

## API overview

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Create student account |
| POST | `/api/auth/login` | Public | Sign in |
| GET | `/api/auth/me` | Signed in | Current profile |
| GET | `/api/events` | Public | Published events |
| GET | `/api/events/:id` | Public | Event details |
| POST | `/api/events` | Admin | Create event |
| PUT | `/api/events/:id` | Admin | Update event |
| DELETE | `/api/events/:id` | Admin | Delete event |
| POST | `/api/registrations/:eventId` | Student | Register |
| GET | `/api/registrations/mine/list` | Signed in | My registrations |
| DELETE | `/api/registrations/:registrationId` | Owner | Cancel registration |
| GET | `/api/registrations/admin/all` | Admin | All registrations |
| PATCH | `/api/registrations/admin/:id/checkin` | Admin | Mark attendance |
| GET | `/api/admin/overview` | Admin | Dashboard totals |
| GET | `/api/admin/students` | Admin | Student directory |

All protected endpoints require `Authorization: Bearer <JWT>`.

## Database entities
- `users`: student and admin accounts; roles are constrained.
- `events`: event information, capacity, deadlines and publication status.
- `registrations`: links a student to an event; unique `(event_id, user_id)` prevents duplicate registrations.

## Important production improvements
This is a competition-ready **working starter**, not a security-audited production deployment. Before using real student data:
- Use HTTPS, a managed PostgreSQL service, backups and restricted database credentials.
- Change all secrets; never commit `.env`.
- Add email verification / password reset and institutional SSO if required.
- Add audit logs for admin changes, pagination and CSV export for large registration lists.
- Add QR-code tickets and QR scanning if the competition rubric rewards touchless check-in.
- Add automated integration tests and deploy to a staging environment.
- Confirm your institution's privacy policy and obtain approval before collecting student information.

## Troubleshooting
- `ECONNREFUSED` from PostgreSQL: make sure PostgreSQL is running and `DATABASE_URL` host/port/database are correct.
- `relation does not exist`: run `npm run db:init`.
- College email rejected: set `COLLEGE_EMAIL_DOMAIN` to the exact domain after `@` in `.env`, then restart the server.
- Port already in use: change `PORT` in `.env`.
- Admin cannot sign in: check `ADMIN_EMAIL` / `ADMIN_PASSWORD`; if the admin row already exists, seed intentionally does not reset its password.


## Student registration and event information updates
- Student account form collects full name, college email, phone number, department and year of study. Password is used only for account login.
- Event organizers can set an optional registration fee (₹0 means free), winner prize amount, and payment instructions. Payment collection/verification is not automated in this version.
- Organizers can upload one event pamphlet as JPG, PNG, WEBP or PDF (maximum 10 MB). Students can view/download it from the event details page.
- Existing databases are updated safely when you run `npm run db:init`; existing event and student records are preserved.
- Docker Compose stores uploaded pamphlets in the persistent `eventhub_uploads` volume.


Pamphlet uploads accept any browser-recognized image MIME type (`image/*`) and PDF, up to 10 MB per file. Actual display support depends on the browser; unsupported image formats can still be downloaded and opened with a compatible application.
