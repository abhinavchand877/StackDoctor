require("dotenv").config();
const bcrypt = require("bcryptjs");
const { pool } = require("../src/db");
(async () => {
  try {
    const name = process.env.ADMIN_NAME || "EventHub Administrator";
    const email = (process.env.ADMIN_EMAIL || "admin@college.edu.in").toLowerCase();
    const password = process.env.ADMIN_PASSWORD || "ChangeMe123!";
    const hash = await bcrypt.hash(password, 12);
    await pool.query(`INSERT INTO users(name,email,password_hash,role) VALUES($1,$2,$3,'admin')
      ON CONFLICT(email) DO NOTHING`, [name,email,hash]);
    const admin = await pool.query("SELECT id FROM users WHERE email=$1", [email]);
    const exists = await pool.query("SELECT COUNT(*)::int AS n FROM events");
    if (exists.rows[0].n === 0) {
      const samples = [
        ["TechNova 2026","A day of coding challenges, emerging technology talks and project showcases.","Technology","Main Auditorium","2026-12-10T09:30:00+05:30", "2026-12-08T23:59:00+05:30",250],
        ["Cultural Canvas","Celebrate music, dance, theatre and creative expression across campus.","Cultural","Open Air Theatre","2026-12-15T16:00:00+05:30","2026-12-13T23:59:00+05:30",400],
        ["Startup Sprint","A fast-paced ideathon where student teams pitch solutions to real problems.","Entrepreneurship","Innovation Lab","2026-12-20T10:00:00+05:30","2026-12-18T23:59:00+05:30",120]
      ];
      for (const s of samples) await pool.query(`INSERT INTO events(title,description,category,venue,event_date,registration_deadline,capacity,created_by)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8)`, [...s,admin.rows[0].id]);
    }
    console.log(`Admin ready: ${email}. Change the starter password after first login.`);
  } catch (e) { console.error(e); process.exitCode = 1; }
  finally { await pool.end(); }
})();