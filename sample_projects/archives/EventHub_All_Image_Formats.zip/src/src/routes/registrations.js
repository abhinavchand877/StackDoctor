const router = require("express").Router();
const { pool } = require("../db");
const { authenticate, adminOnly } = require("../middleware/auth");
router.post("/:eventId", authenticate, async (req, res, next) => {
  try {
    if (req.user.role !== "student") return res.status(403).json({ error: "Only student accounts can register." });
    const { phone, department, year } = req.body;
    if (!phone || !String(phone).trim()) return res.status(400).json({ error: "Enter your phone number to register." });
    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      const ev = await client.query("SELECT * FROM events WHERE id=$1 AND is_published=TRUE FOR UPDATE", [req.params.eventId]);
      if (!ev.rows[0]) { await client.query("ROLLBACK"); return res.status(404).json({ error: "Event not found." }); }
      const event = ev.rows[0];
      if (new Date(event.event_date) <= new Date()) { await client.query("ROLLBACK"); return res.status(400).json({ error: "Registration is closed because this event has started." }); }
      if (event.registration_deadline && new Date(event.registration_deadline) < new Date()) { await client.query("ROLLBACK"); return res.status(400).json({ error: "Registration deadline has passed." }); }
      const count = await client.query("SELECT COUNT(*)::int AS n FROM registrations WHERE event_id=$1 AND status <> 'cancelled'", [event.id]);
      if (count.rows[0].n >= event.capacity) { await client.query("ROLLBACK"); return res.status(409).json({ error: "This event is full." }); }
      await client.query("UPDATE users SET phone=$1,department=$2,year=$3 WHERE id=$4", [String(phone).trim(), department || null, year || null, req.user.id]);
      const r = await client.query("INSERT INTO registrations(event_id,user_id,phone,department,year) VALUES($1,$2,$3,$4,$5) RETURNING *", [event.id, req.user.id, String(phone).trim(), department || null, year || null]);
      await client.query("COMMIT");
      res.status(201).json({ registration: r.rows[0], message: "You are registered!" });
    } catch (e) { await client.query("ROLLBACK"); if (e.code === "23505") return res.status(409).json({ error: "You are already registered for this event." }); throw e; }
    finally { client.release(); }
  } catch (e) { next(e); }
});
router.get("/mine/list", authenticate, async (req, res, next) => {
  try {
    const r = await pool.query(`SELECT r.id AS registration_id,r.status,r.registered_at,r.checked_in_at,e.*
      FROM registrations r JOIN events e ON e.id=r.event_id WHERE r.user_id=$1 ORDER BY r.registered_at DESC`, [req.user.id]);
    res.json({ registrations: r.rows });
  } catch (e) { next(e); }
});
router.delete("/:registrationId", authenticate, async (req, res, next) => {
  try {
    const r = await pool.query("UPDATE registrations SET status='cancelled' WHERE id=$1 AND user_id=$2 AND status='registered' RETURNING id", [req.params.registrationId, req.user.id]);
    if (!r.rows[0]) return res.status(404).json({ error: "Active registration not found." });
    res.json({ message: "Registration cancelled." });
  } catch (e) { next(e); }
});
router.get("/admin/all", authenticate, adminOnly, async (req, res, next) => {
  try {
    const { eventId, q } = req.query;
    const values = [];
    let where = "WHERE 1=1";
    if (eventId) { values.push(eventId); where += ` AND r.event_id=$${values.length}`; }
    if (q) { values.push(`%${q}%`); where += ` AND (u.name ILIKE $${values.length} OR u.email ILIKE $${values.length})`; }
    const r = await pool.query(`SELECT r.id,r.status,r.registered_at,r.checked_in_at,u.name,u.email,COALESCE(r.phone,u.phone) AS phone,COALESCE(r.department,u.department) AS department,COALESCE(r.year,u.year) AS year,e.title AS event_title,e.id AS event_id
      FROM registrations r JOIN users u ON u.id=r.user_id JOIN events e ON e.id=r.event_id ${where}
      ORDER BY r.registered_at DESC`, values);
    res.json({ registrations: r.rows });
  } catch (e) { next(e); }
});
router.patch("/admin/:id/checkin", authenticate, adminOnly, async (req, res, next) => {
  try {
    const r = await pool.query("UPDATE registrations SET status='attended',checked_in_at=NOW() WHERE id=$1 AND status='registered' RETURNING id,status,checked_in_at", [req.params.id]);
    if (!r.rows[0]) return res.status(404).json({ error: "Active registration not found or already checked in." });
    res.json({ registration: r.rows[0], message: "Student checked in." });
  } catch (e) { next(e); }
});
module.exports = router;