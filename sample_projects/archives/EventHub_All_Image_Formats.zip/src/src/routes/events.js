const router = require("express").Router();
const { pool } = require("../db");
const { authenticate, adminOnly } = require("../middleware/auth");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const uploadDir = path.join(__dirname, "../../public/uploads");
fs.mkdirSync(uploadDir, { recursive: true });
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => cb(null, `event-${Date.now()}-${Math.round(Math.random()*1e9)}${path.extname(file.originalname).toLowerCase()}`)
});
const pamphletUpload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    // Accept any image MIME type supported by the browser, plus PDF.
    const mime = String(file.mimetype || "").toLowerCase();
    const ok = mime.startsWith("image/") || mime === "application/pdf";
    cb(ok ? null : new Error("Please upload an image file or a PDF document."), ok);
  }
});
router.get("/", async (req, res, next) => {
  try {
    const { q, category, status } = req.query;
    const values = []; let where = "WHERE e.is_published = TRUE";
    if (q) { values.push(`%${q}%`); where += ` AND (e.title ILIKE $${values.length} OR e.description ILIKE $${values.length})`; }
    if (category) { values.push(category); where += ` AND e.category=$${values.length}`; }
    if (status === "upcoming") where += " AND e.event_date >= NOW()";
    const r = await pool.query(`SELECT e.*, u.name AS organizer_name,
      (SELECT COUNT(*)::int FROM registrations r WHERE r.event_id=e.id AND r.status <> 'cancelled') AS registered_count
      FROM events e LEFT JOIN users u ON u.id=e.created_by ${where} ORDER BY e.event_date ASC`, values);
    res.json({ events: r.rows });
  } catch (e) { next(e); }
});
router.get("/:id", async (req, res, next) => {
  try {
    const r = await pool.query("SELECT e.*,u.name AS organizer_name,(SELECT COUNT(*)::int FROM registrations r WHERE r.event_id=e.id AND r.status <> 'cancelled') AS registered_count FROM events e LEFT JOIN users u ON u.id=e.created_by WHERE e.id=$1 AND e.is_published=TRUE", [req.params.id]);
    if (!r.rows[0]) return res.status(404).json({ error: "Event not found." });
    res.json({ event: r.rows[0] });
  } catch (e) { next(e); }
});
router.post("/", authenticate, adminOnly, async (req, res, next) => {
  try {
    const { title, description, category, venue, event_date, registration_deadline, capacity, banner_url, registration_fee, prize_money, payment_instructions } = req.body;
    if (!title || !description || !venue || !event_date) return res.status(400).json({ error: "Title, description, venue and event date are required." });
    const fee = Number(registration_fee || 0), prize = Number(prize_money || 0);
    if (!Number.isFinite(fee) || fee < 0 || !Number.isFinite(prize) || prize < 0) return res.status(400).json({ error: "Fee and prize amounts must be zero or positive numbers." });
    const r = await pool.query(`INSERT INTO events(title,description,category,venue,event_date,registration_deadline,capacity,banner_url,registration_fee,prize_money,payment_instructions,created_by,is_published)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,TRUE) RETURNING *`,
      [title,description,category || "General",venue,event_date,registration_deadline || null,capacity || 100,banner_url || null,fee,prize,payment_instructions || null,req.user.id]);
    res.status(201).json({ event: r.rows[0] });
  } catch (e) { next(e); }
});
router.post("/:id/pamphlet", authenticate, adminOnly, (req, res, next) => {
  pamphletUpload.single("pamphlet")(req, res, async err => {
    if (err) return res.status(400).json({ error: err.message });
    if (!req.file) return res.status(400).json({ error: "Choose a pamphlet file first." });
    try {
      const url = `/uploads/${req.file.filename}`;
      const result = await pool.query("UPDATE events SET pamphlet_url=$1,updated_at=NOW() WHERE id=$2 RETURNING id,pamphlet_url", [url, req.params.id]);
      if (!result.rows[0]) return res.status(404).json({ error: "Event not found." });
      res.json({ event: result.rows[0], message: "Event pamphlet uploaded." });
    } catch (e) { next(e); }
  });
});
router.put("/:id", authenticate, adminOnly, async (req, res, next) => {
  try {
    const { title, description, category, venue, event_date, registration_deadline, capacity, banner_url, registration_fee, prize_money, payment_instructions, is_published } = req.body;
    const r = await pool.query(`UPDATE events SET title=COALESCE($1,title),description=COALESCE($2,description),category=COALESCE($3,category),venue=COALESCE($4,venue),event_date=COALESCE($5,event_date),registration_deadline=$6,capacity=COALESCE($7,capacity),banner_url=$8,registration_fee=COALESCE($9,registration_fee),prize_money=COALESCE($10,prize_money),payment_instructions=$11,is_published=COALESCE($12,is_published),updated_at=NOW() WHERE id=$13 RETURNING *`,
      [title,description,category,venue,event_date,registration_deadline || null,capacity,banner_url || null,registration_fee,prize_money,payment_instructions || null,is_published,req.params.id]);
    if (!r.rows[0]) return res.status(404).json({ error: "Event not found." });
    res.json({ event: r.rows[0] });
  } catch (e) { next(e); }
});
router.delete("/:id", authenticate, adminOnly, async (req, res, next) => {
  try {
    const r = await pool.query("DELETE FROM events WHERE id=$1 RETURNING id", [req.params.id]);
    if (!r.rows[0]) return res.status(404).json({ error: "Event not found." });
    res.json({ message: "Event deleted." });
  } catch (e) { next(e); }
});
module.exports = router;
