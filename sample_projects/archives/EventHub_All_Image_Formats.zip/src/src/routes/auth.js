const router = require("express").Router();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { pool } = require("../db");
const { authenticate } = require("../middleware/auth");

const emailOk = value => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value || "");
router.post("/register", async (req, res, next) => {
  try {
    const { name, email, password, department, year, phone } = req.body;
    const normalized = String(email || "").trim().toLowerCase();
    const domain = (process.env.COLLEGE_EMAIL_DOMAIN || "").trim().toLowerCase();
    if (!name?.trim() || !emailOk(normalized) || !password || password.length < 8)
      return res.status(400).json({ error: "Enter your name, valid college email and a password of at least 8 characters." });
    if (domain && !normalized.endsWith("@" + domain))
      return res.status(400).json({ error: `Use your college email ending in @${domain}.` });
    const hash = await bcrypt.hash(password, 12);
    const result = await pool.query(
      "INSERT INTO users(name,email,password_hash,department,year,phone,role) VALUES($1,$2,$3,$4,$5,$6,'student') RETURNING id,name,email,department,year,phone,role",
      [name.trim(), normalized, hash, department || null, year || null, phone || null]
    );
    res.status(201).json({ message: "Account created. You can now sign in.", user: result.rows[0] });
  } catch (e) {
    if (e.code === "23505") return res.status(409).json({ error: "This email is already registered." });
    next(e);
  }
});
router.post("/login", async (req, res, next) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const result = await pool.query("SELECT * FROM users WHERE email=$1", [email]);
    const user = result.rows[0];
    if (!user || !(await bcrypt.compare(req.body.password || "", user.password_hash)))
      return res.status(401).json({ error: "Incorrect email or password." });
    const token = jwt.sign({ id: user.id, role: user.role, email: user.email, name: user.name }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || "8h" });
    res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role, department: user.department, year: user.year, phone: user.phone } });
  } catch (e) { next(e); }
});
router.get("/me", authenticate, async (req, res, next) => {
  try {
    const r = await pool.query("SELECT id,name,email,role,department,year,phone FROM users WHERE id=$1", [req.user.id]);
    if (!r.rows[0]) return res.status(404).json({ error: "Account not found." });
    res.json({ user: r.rows[0] });
  } catch (e) { next(e); }
});
module.exports = router;