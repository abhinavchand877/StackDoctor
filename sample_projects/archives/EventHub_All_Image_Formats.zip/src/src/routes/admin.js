const router = require("express").Router();
const { pool } = require("../db");
const { authenticate, adminOnly } = require("../middleware/auth");
router.use(authenticate, adminOnly);
router.get("/overview", async (_req, res, next) => {
  try {
    const [events, students, regs, attended] = await Promise.all([
      pool.query("SELECT COUNT(*)::int AS n FROM events"),
      pool.query("SELECT COUNT(*)::int AS n FROM users WHERE role='student'"),
      pool.query("SELECT COUNT(*)::int AS n FROM registrations WHERE status <> 'cancelled'"),
      pool.query("SELECT COUNT(*)::int AS n FROM registrations WHERE status='attended'")
    ]);
    res.json({ events: events.rows[0].n, students: students.rows[0].n, registrations: regs.rows[0].n, attended: attended.rows[0].n });
  } catch (e) { next(e); }
});
router.get("/students", async (req, res, next) => {
  try {
    const q = `%${req.query.q || ""}%`;
    const r = await pool.query(`SELECT u.id,u.name,u.email,u.department,u.year,u.created_at,COUNT(r.id)::int AS registration_count
      FROM users u LEFT JOIN registrations r ON r.user_id=u.id AND r.status <> 'cancelled'
      WHERE u.role='student' AND (u.name ILIKE $1 OR u.email ILIKE $1)
      GROUP BY u.id ORDER BY u.created_at DESC`, [q]);
    res.json({ students: r.rows });
  } catch (e) { next(e); }
});
module.exports = router;